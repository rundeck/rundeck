//
jQuery(function () {
    if (typeof(RDPLUGIN) != 'object') {
        window.RDPLUGIN = {};
    }
    RDPLUGIN['test-ui'] = "rundeck-ui-plugin-examples";
});