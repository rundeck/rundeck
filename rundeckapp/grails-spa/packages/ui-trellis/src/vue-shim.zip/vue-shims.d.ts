declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}

declare module 'vue2-ace-editor' {

}
declare module 'markdown-it-vue'{

}
