this is a message of the day
